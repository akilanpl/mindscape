"""Object-centric stability research."""
