"""Mindscape deterministic research foundation."""
__version__ = "0.1.0"
